package me.henryfbp.quotes

class ImageQuote(var image: Int, var imageHD: Int, var quote: Int)