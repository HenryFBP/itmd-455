package me.henryfbp.temperatureconverter.lib;

public class TemperatureUnit {

    public String unit;

    public TemperatureUnit(String unit) {
        this.unit = unit;
    }
}
