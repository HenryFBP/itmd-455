```
09-10 22:58:51.127 341-341/me.henryfbp.temperatureconverter I/bg_color: 0.2->Color(0.2, 0.0, 0.8, 1.0, sRGB IEC61966-2.1)
09-10 22:58:51.127 341-341/me.henryfbp.temperatureconverter I/main_tempTextEdit_fahrenheit: 20
09-10 22:58:51.893 341-341/me.henryfbp.temperatureconverter I/bg_color: 0.3->Color(0.3, 0.0, 0.7, 1.0, sRGB IEC61966-2.1)
09-10 22:58:51.893 341-341/me.henryfbp.temperatureconverter I/main_tempTextEdit_fahrenheit: 30
09-10 22:58:52.622 341-341/me.henryfbp.temperatureconverter I/bg_color: 0.4->Color(0.4, 0.0, 0.6, 1.0, sRGB IEC61966-2.1)
09-10 22:58:52.622 341-341/me.henryfbp.temperatureconverter I/main_tempTextEdit_fahrenheit: 40
09-10 22:58:54.150 341-341/me.henryfbp.temperatureconverter I/bg_color: 0.5->Color(0.5, 0.0, 0.5, 1.0, sRGB IEC61966-2.1)
09-10 22:58:54.150 341-341/me.henryfbp.temperatureconverter I/main_tempTextEdit_fahrenheit: 50
09-10 22:58:55.183 341-341/me.henryfbp.temperatureconverter I/bg_color: 0.6->Color(0.6, 0.0, 0.39999998, 1.0, sRGB IEC61966-2.1)
09-10 22:58:55.185 341-341/me.henryfbp.temperatureconverter I/main_tempTextEdit_fahrenheit: 60
09-10 22:58:55.838 341-341/me.henryfbp.temperatureconverter I/bg_color: 0.7->Color(0.7, 0.0, 0.3, 1.0, sRGB IEC61966-2.1)
09-10 22:58:55.838 341-341/me.henryfbp.temperatureconverter I/main_tempTextEdit_fahrenheit: 70
```